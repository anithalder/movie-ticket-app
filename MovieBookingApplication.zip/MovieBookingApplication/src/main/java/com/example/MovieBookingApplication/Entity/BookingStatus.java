package com.example.MovieBookingApplication.Entity;

public enum BookingStatus {
    PENDING,
    CONFIRMED,
    CANCELLING,
    CANCELLED
}
